import { useEffect, useState } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from './lib/supabase'
import Import from './views/Import'
import Run from './views/Run'
import Board from './views/Board'

const today = () => new Date().toISOString().slice(0, 10)

const TABS = [
  { id: 'import', step: '01', label: 'นำเข้าข้อมูล' },
  { id: 'run',    step: '02', label: 'คำนวณยอดเติม' },
  { id: 'board',  step: '03', label: 'KPI และค่าคำนวณ' },
] as const

type Tab = (typeof TABS)[number]['id']

function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  async function signIn(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true); setErr('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) setErr('เข้าสู่ระบบไม่สำเร็จ — ตรวจอีเมลและรหัสผ่านอีกครั้ง')
    setBusy(false)
  }

  return (
    <div className="login">
      <form onSubmit={signIn}>
        <h1>ระบบเติมสินค้า</h1>
        <p>คลังแม่กลอง</p>
        <input type="email" placeholder="อีเมล" value={email} required
          autoComplete="username" onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="รหัสผ่าน" value={password} required
          autoComplete="current-password" onChange={(e) => setPassword(e.target.value)} />
        <button className="btn" type="submit" disabled={busy}>
          {busy ? 'กำลังเข้าสู่ระบบ…' : 'เข้าสู่ระบบ'}
        </button>
        {err && <div className="note bad">{err}</div>}
        <p style={{ fontSize: 12, marginTop: 4 }}>
          สร้างผู้ใช้ได้ที่ Supabase &rsaquo; Authentication &rsaquo; Users &rsaquo; Add user
        </p>
      </form>
    </div>
  )
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null)
  const [ready, setReady] = useState(false)
  const [tab, setTab] = useState<Tab>('import')
  const [snapshotDate, setSnapshotDate] = useState(today())

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true) })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])

  if (!ready) return null
  if (!session) return <Login />

  return (
    <div className="shell">
      <aside className="rail">
        <div className="brand">
          <h1>ระบบเติมสินค้า</h1>
          <p>คลังแม่กลอง</p>
        </div>
        <nav className="nav">
          {TABS.map((t) => (
            <button key={t.id} aria-current={tab === t.id} onClick={() => setTab(t.id)}>
              <span className="step">{t.step}</span>
              {t.label}
            </button>
          ))}
        </nav>
        <footer>
          <div style={{ marginBottom: 6, wordBreak: 'break-all' }}>{session.user.email}</div>
          <button onClick={() => supabase.auth.signOut()}>ออกจากระบบ</button>
        </footer>
      </aside>

      <main className="main">
        {tab === 'import' && <Import snapshotDate={snapshotDate} setSnapshotDate={setSnapshotDate} />}
        {tab === 'run' && <Run snapshotDate={snapshotDate} />}
        {tab === 'board' && <Board />}
      </main>
    </div>
  )
}
